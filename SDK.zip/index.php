<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="UTF-8&quot;utf-8&quot;">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="applicable-device" content="pc,mobile">
<link href="/favicon.ico" rel="shortcut icon">
<title>在线测试 - 至尊码支付</title>
<link rel="stylesheet" href="./css/bootstrap.min.css">
<link rel="stylesheet" href="./css/style.css">
<link rel="stylesheet" href="./css/m_reset.css">
<link href="./css/demo_reset.css" rel="stylesheet" type="text/css">
</head>
<body>

<div class="container">
   <div class="row">

    <div class="col-lg-12 col-sx-12">
        <div class="head">
  <a target="_blank" href="/">返回首页</a>

</div>  
<form name="alipayment" action="epayapi.php" method="post" target="_blank">
    <div id="body" style="clear:left">
      <div class="content">
            <div class="content-head">
                                 <!--<div class="logo" align="center">
         <a href="/"><img src="./img/logo.png"></a>
     </div>-->
                <div class="order">

                <span class="sleft">订单编号: 
				<input size="30" name="WIDout_trade_no" value="<?php echo date("YmdHis").mt_rand(100,999); ?>" style="background-color:transparent;border:0;"></span>
				<br>
				<span class="sleft">商品名称: 
				<input size="30" name="WIDsubject" value="至尊码支付在线付款测试"></span>
                <span class="sright">收款商家: <input type="text" id="param" name="param" value="至尊网络" style="background-color:transparent;border:0;"></span>
            </div>
            </div>
            <div class="step step2">
                <ul class="steps clearfix">
                    <li>选择商品</li>
                    <li class="active">确认付款</li>
                    <li>下单成功</li>

                </ul>
            </div>

            <div class="pay_amount">
                <span class="amount_text">支付金额:</span>
                <span class="amount font-red">￥
				<input size="30" name="WIDtotal_fee" value="<?php echo bcdiv(mt_rand(1,100),100,2);?>" style="background-color:transparent;border:0;width:64px;"></span>
            </div>



            <div class="order" style="margin-top: 20px;margin-bottom: 5px;">
                <span class="address-title">请选择付款方式</span>
            </div>
            <div class="ways">
                <span style="outline: none;border: none;">
                    <dd>
                        <input type="radio" name="type" id="alipay" value="alipay" checked=""><label for="alipay">支付宝</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="type" value="qqpay" id="qqpay"><label for="qqpay">QQ钱包</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="type" value="wxpay" id="wxpay"><label for="wxpay">微信</label></dd>
		        </span></div>
                <input hidden="hidden" type="radio" name="type" value="alipay">
                
                <div class="w1080 PayMethod12">
			    <div class="row">
    				
                    
		        </div>
                <input hidden="hidden" type="radio" name="type" value="alipay">

                
            </div>
            </div>
            <div class="go-pay">
                <span style="margin-right: 10px">在线测试付款商品不会发货</span>
                        <input type="submit" class="buy-button" style="width: 100px;cursor: pointer;" value="发起支付">

                <!--<button class="buy-button" style="width: 100px;">立即支付</button>-->
            </div>

        </div>
</form>
        <div class="foot">
    <p> <span> © Copyright <?php echo date('Y');?><a href="/">至尊码支付</a>  </span></p>
</div>    </div>

</div>
</div>
</body></html>